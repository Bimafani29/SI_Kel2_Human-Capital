<?php
include 'koneksi.php';

$kode = $_POST['kode'];
$nama = $_POST['nama'];
$ketua = $_POST['ketua'];

$sql ="insert into divisi (kode_divisi, nama_divisi, ketua_divisi) values('$kode', '$nama', '$ketua')";
$simpan = mysqli_query($konek, $sql) or die ("gagal menambahkan data : ".mysqli_error($konek));

header ('location:tampilkan_divisi.php')

?>