<?php
include 'koneksi.php';

$sql = "select * from divisi";
$select = mysqli_query($konek,$sql) or die ("gagal membaca database");
echo ("<table> <tr> <th>Kode Divisi</th> <th>Nama Divisi</th> <th>Ketua Divisi</> </tr>");
while ($row = mysqli_fetch_array($select)) {
    $kode = $row['kode_divisi'];
    $nama = $row['nama_divisi'];
    $ketua = $row['ketua_divisi'];

    echo ("<tr> <td>$kode</td> <td>$nama<td> <td>$ketua<td> </tr>");
}
echo ("</table>");
echo ("<a href='hmsi_unpam.html'> Input Divisi </a>");

?>