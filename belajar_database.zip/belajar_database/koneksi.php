<?php 
$konek = mysqli_connect("localhost", "root", "", "HMSI") or die("koneksi gagal!");

?>